-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** {
    *** Companion;
}
-keepclasseswithmembers class kotlinx.serialization.json.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-keep,includedescriptorclasses class com.lumavault.app.data.**$$serializer { *; }
-keepclassmembers class com.lumavault.app.data.** {
    *** Companion;
}
-keepclasseswithmembers class com.lumavault.app.data.** {
    kotlinx.serialization.KSerializer serializer(...);
}
