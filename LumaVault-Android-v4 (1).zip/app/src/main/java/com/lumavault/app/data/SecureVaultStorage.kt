package com.lumavault.app.data

import android.content.Context
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec

/**
 * Полностью локальное изолированное хранилище.
 * - Хранится в приватной песочнице приложения (context.filesDir/vault_sealed) с правами 700 (owner-only).
 * - Автоматически создаётся при запуске и полностью удаляется ОС Android при удалении приложения.
 * - Бэкапы и перенос данных отключены в AndroidManifest.
 * - Всё содержимое шифруется алгоритмом AES-256-GCM с ключом в аппаратном Android Keystore (StrongBox / TEE).
 */
class SecureVaultStorage(private val context: Context) {

    companion object {
        private const val KEYSTORE_PROVIDER = "AndroidKeyStore"
        private const val KEY_ALIAS = "lumavault_aes256_master_v1"
        private const val VAULT_FOLDER_NAME = "vault_sealed"
        private const val VAULT_DATA_FILE = "vault_items.enc"
        private const val SECURITY_CONFIG_FILE = "vault_auth.enc"
        private const val PBKDF2_ITERATIONS = 120_000
        private const val PBKDF2_KEY_BITS = 256
    }

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    private val secureRandom = SecureRandom()

    val vaultDirectory: File
        get() {
            val dir = File(context.filesDir, VAULT_FOLDER_NAME)
            if (!dir.exists()) {
                dir.mkdirs()
            }
            dir.setReadable(false, false)
            dir.setReadable(true, true)
            dir.setWritable(false, false)
            dir.setWritable(true, true)
            dir.setExecutable(false, false)
            dir.setExecutable(true, true)
            return dir
        }

    private val vaultFile: File
        get() = File(vaultDirectory, VAULT_DATA_FILE)

    private val configFile: File
        get() = File(vaultDirectory, SECURITY_CONFIG_FILE)

    fun isPinConfigured(): Boolean = configFile.exists()

    fun getHardwareSecurityInfo(): String {
        return try {
            val keyStore = KeyStore.getInstance(KEYSTORE_PROVIDER).apply { load(null) }
            val hasKey = keyStore.containsAlias(KEY_ALIAS)
            if (hasKey) "AES-256-GCM • Android Keystore (Активен)" else "AES-256-GCM • Готов к инициализации"
        } catch (_: Exception) {
            "AES-256-GCM • Android Keystore"
        }
    }

    private fun getOrCreateMasterKey(): SecretKey {
        val keyStore = KeyStore.getInstance(KEYSTORE_PROVIDER).apply { load(null) }
        val existing = keyStore.getKey(KEY_ALIAS, null) as? SecretKey
        if (existing != null) return existing

        return try {
            generateKey(useStrongBox = Build.VERSION.SDK_INT >= Build.VERSION_CODES.P)
        } catch (_: Exception) {
            generateKey(useStrongBox = false)
        }
    }

    private fun generateKey(useStrongBox: Boolean): SecretKey {
        val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE_PROVIDER)
        val builder = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .setRandomizedEncryptionRequired(true)

        if (useStrongBox && Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            builder.setIsStrongBoxBacked(true)
        }

        keyGenerator.init(builder.build())
        return keyGenerator.generateKey()
    }

    private fun encryptBytes(plain: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateMasterKey())
        val iv = cipher.iv
        val encrypted = cipher.doFinal(plain)
        val out = ByteArray(1 + iv.size + encrypted.size)
        out[0] = iv.size.toByte()
        System.arraycopy(iv, 0, out, 1, iv.size)
        System.arraycopy(encrypted, 0, out, 1 + iv.size, encrypted.size)
        return out
    }

    private fun decryptBytes(blob: ByteArray): ByteArray {
        require(blob.size > 16) { "Corrupted encrypted payload" }
        val ivLen = blob[0].toInt() and 0xFF
        require(ivLen in 12..16 && blob.size > 1 + ivLen) { "Invalid IV length" }
        val iv = blob.copyOfRange(1, 1 + ivLen)
        val cipherText = blob.copyOfRange(1 + ivLen, blob.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateMasterKey(), GCMParameterSpec(128, iv))
        return cipher.doFinal(cipherText)
    }

    private fun writeAtomically(target: File, data: ByteArray) {
        val tmp = File(vaultDirectory, "${target.name}.tmp")
        tmp.writeBytes(data)
        tmp.setReadable(false, false)
        tmp.setReadable(true, true)
        tmp.setWritable(false, false)
        tmp.setWritable(true, true)
        if (!tmp.renameTo(target)) {
            target.writeBytes(data)
            tmp.delete()
        }
        target.setReadable(false, false)
        target.setReadable(true, true)
    }

    private fun hashPin(pin: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, PBKDF2_ITERATIONS, PBKDF2_KEY_BITS)
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        return factory.generateSecret(spec).encoded
    }

    fun setupPin(pin: String, biometricEnabled: Boolean): SecurityConfig {
        val salt = ByteArray(16).also { secureRandom.nextBytes(it) }
        val hash = hashPin(pin, salt)
        val config = SecurityConfig(
            pinHashBase64 = Base64.getEncoder().encodeToString(hash),
            pinSaltBase64 = Base64.getEncoder().encodeToString(salt),
            pinLength = pin.length,
            biometricEnabled = biometricEnabled,
            autoLockOnBackground = true
        )
        saveSecurityConfig(config)
        if (!vaultFile.exists()) {
            saveEntries(emptyList())
        }
        return config
    }

    fun loadSecurityConfig(): SecurityConfig? {
        if (!configFile.exists()) return null
        return try {
            val decrypted = decryptBytes(configFile.readBytes())
            json.decodeFromString<SecurityConfig>(decrypted.decodeToString())
        } catch (_: Exception) {
            null
        }
    }

    fun saveSecurityConfig(config: SecurityConfig) {
        val serialized = json.encodeToString(config).encodeToByteArray()
        writeAtomically(configFile, encryptBytes(serialized))
    }

    fun verifyPin(pin: String): Boolean {
        val config = loadSecurityConfig() ?: return false
        val salt = Base64.getDecoder().decode(config.pinSaltBase64)
        val expected = Base64.getDecoder().decode(config.pinHashBase64)
        val candidate = hashPin(pin, salt)
        return MessageDigest.isEqual(expected, candidate)
    }

    fun loadEntries(): List<VaultEntry> {
        if (!vaultFile.exists()) return emptyList()
        return try {
            val decrypted = decryptBytes(vaultFile.readBytes())
            json.decodeFromString<VaultPayload>(decrypted.decodeToString()).entries
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveEntries(entries: List<VaultEntry>) {
        val payload = VaultPayload(entries = entries)
        val serialized = json.encodeToString(payload).encodeToByteArray()
        writeAtomically(vaultFile, encryptBytes(serialized))
    }
}
