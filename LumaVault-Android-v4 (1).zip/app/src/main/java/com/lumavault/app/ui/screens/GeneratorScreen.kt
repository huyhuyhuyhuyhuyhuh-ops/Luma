package com.lumavault.app.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Casino
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.RecordVoiceOver
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lumavault.app.generator.ClusterDensity
import com.lumavault.app.generator.GeneratorConfig
import com.lumavault.app.generator.GeneratorMode
import com.lumavault.app.generator.PasswordGeneratorEngine
import com.lumavault.app.generator.PhoneticVibe
import com.lumavault.app.generator.WordTransformMode
import com.lumavault.app.ui.components.ExpressiveButton
import com.lumavault.app.ui.components.ExpressiveChip
import com.lumavault.app.ui.components.ExpressiveIconButton
import com.lumavault.app.ui.components.colorizePassword
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun GeneratorScreen(
    onCopyPassword: (String) -> Unit,
    onSaveToVault: (String) -> Unit
) {
    var config by remember { mutableStateOf(GeneratorConfig()) }
    val history = remember { mutableStateListOf<String>() }
    var currentIndex by remember { mutableIntStateOf(-1) }
    var slideDirection by remember { mutableIntStateOf(1) }
    var diceRotationTarget by remember { mutableFloatStateOf(0f) }
    var justCopied by remember { mutableStateOf(false) }

    fun rollNewPassword(cfg: GeneratorConfig = config) {
        val next = PasswordGeneratorEngine.generate(cfg)
        if (history.size >= 100) {
            history.removeAt(0)
        }
        history.add(next)
        currentIndex = history.lastIndex
        slideDirection = 1
        diceRotationTarget += 180f
        justCopied = false
    }

    LaunchedEffect(Unit) {
        if (history.isEmpty()) {
            rollNewPassword()
        }
    }

    LaunchedEffect(justCopied) {
        if (justCopied) {
            delay(1600)
            justCopied = false
        }
    }

    val currentPassword = if (currentIndex in history.indices) history[currentIndex] else ""
    val canGoBack = currentIndex > 0
    val canGoForward = currentIndex in 0 until history.lastIndex

    val strength = remember(currentPassword) {
        PasswordGeneratorEngine.evaluateStrength(currentPassword)
    }

    val strengthProgress by animateFloatAsState(
        targetValue = strength.progress,
        animationSpec = spring(dampingRatio = 0.65f, stiffness = 320f),
        label = "strength_bar"
    )
    val strengthColor by animateColorAsState(
        targetValue = when {
            strength.progress < 0.35f -> MaterialTheme.colorScheme.error
            strength.progress < 0.65f -> Color(0xFFFFB74D)
            strength.progress < 0.9f -> MaterialTheme.colorScheme.secondary
            else -> MaterialTheme.colorScheme.primary
        },
        label = "strength_color"
    )
    val diceRotation by animateFloatAsState(
        targetValue = diceRotationTarget,
        animationSpec = spring(dampingRatio = 0.52f, stiffness = 300f),
        label = "dice_rot"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp)
            .padding(top = 12.dp, bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Генератор",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "Умная фонетика, шифровка слов и история",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (history.isNotEmpty()) {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = MaterialTheme.colorScheme.secondaryContainer
                ) {
                    Text(
                        text = "#${currentIndex + 1} / ${history.size}",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }
        }

        Surface(
            shape = RoundedCornerShape(32.dp),
            color = MaterialTheme.colorScheme.surfaceContainer,
            tonalElevation = 3.dp,
            modifier = Modifier
                .fillMaxWidth()
                .animateContentSize(spring(dampingRatio = 0.68f, stiffness = 360f))
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(22.dp))
                        .background(MaterialTheme.colorScheme.surfaceContainerLowest)
                        .padding(horizontal = 16.dp, vertical = 22.dp),
                    contentAlignment = Alignment.Center
                ) {
                    AnimatedContent(
                        targetState = Pair(currentIndex, currentPassword),
                        transitionSpec = {
                            val dir = slideDirection
                            (slideInHorizontally(
                                animationSpec = spring(dampingRatio = 0.68f, stiffness = 380f)
                            ) { width -> dir * (width / 3) } + fadeIn(tween(180))) togetherWith
                                (slideOutHorizontally(
                                    animationSpec = tween(150)
                                ) { width -> -dir * (width / 3) } + fadeOut(tween(130)))
                        },
                        label = "password_slide"
                    ) { (_, pass) ->
                        Text(
                            text = colorizePassword(pass),
                            fontFamily = FontFamily.Monospace,
                            fontSize = if (pass.length > 22) 19.sp else 23.sp,
                            lineHeight = 30.sp,
                            textAlign = TextAlign.Center,
                            letterSpacing = 0.8.sp
                        )
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = strength.label,
                            style = MaterialTheme.typography.labelLarge,
                            color = strengthColor
                        )
                        Text(
                            text = "${currentPassword.length} симв. • ~${strength.entropyBits} бит",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(50))
                            .background(MaterialTheme.colorScheme.surfaceContainerHighest)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(strengthProgress.coerceIn(0.05f, 1f))
                                .height(8.dp)
                                .clip(RoundedCornerShape(50))
                                .background(strengthColor)
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ExpressiveIconButton(
                        onClick = {
                            if (canGoBack) {
                                slideDirection = -1
                                currentIndex--
                                justCopied = false
                            }
                        },
                        enabled = canGoBack,
                        containerColor = MaterialTheme.colorScheme.surfaceContainerHighest,
                        contentColor = MaterialTheme.colorScheme.onSurface,
                        defaultCorner = 24.dp,
                        pressedCorner = 12.dp,
                        modifier = Modifier.size(56.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "Предыдущий пароль",
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    ExpressiveButton(
                        onClick = { rollNewPassword() },
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary,
                        defaultCorner = 28.dp,
                        pressedCorner = 14.dp,
                        pressScale = 1.055f,
                        contentPadding = PaddingValues(vertical = 16.dp, horizontal = 14.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Casino,
                            contentDescription = null,
                            modifier = Modifier
                                .size(22.dp)
                                .graphicsLayer { rotationZ = diceRotation }
                        )
                        Text(
                            text = "Сгенерировать",
                            style = MaterialTheme.typography.titleMedium
                        )
                    }

                    ExpressiveIconButton(
                        onClick = {
                            if (canGoForward) {
                                slideDirection = 1
                                currentIndex++
                                justCopied = false
                            }
                        },
                        enabled = canGoForward,
                        containerColor = MaterialTheme.colorScheme.surfaceContainerHighest,
                        contentColor = MaterialTheme.colorScheme.onSurface,
                        defaultCorner = 24.dp,
                        pressedCorner = 12.dp,
                        modifier = Modifier.size(56.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowForward,
                            contentDescription = "Следующий пароль",
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    ExpressiveButton(
                        onClick = {
                            if (currentPassword.isNotEmpty()) {
                                onCopyPassword(currentPassword)
                                justCopied = true
                            }
                        },
                        containerColor = if (justCopied) MaterialTheme.colorScheme.secondaryContainer
                        else MaterialTheme.colorScheme.surfaceContainerHigh,
                        contentColor = if (justCopied) MaterialTheme.colorScheme.onSecondaryContainer
                        else MaterialTheme.colorScheme.onSurface,
                        defaultCorner = 22.dp,
                        pressedCorner = 12.dp,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = if (justCopied) Icons.Rounded.Check else Icons.Rounded.ContentCopy,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = if (justCopied) "Скопировано" else "Копировать",
                            style = MaterialTheme.typography.labelLarge
                        )
                    }

                    ExpressiveButton(
                        onClick = {
                            if (currentPassword.isNotEmpty()) {
                                onSaveToVault(currentPassword)
                            }
                        },
                        containerColor = MaterialTheme.colorScheme.tertiaryContainer,
                        contentColor = MaterialTheme.colorScheme.onTertiaryContainer,
                        defaultCorner = 22.dp,
                        pressedCorner = 12.dp,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Save,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "В хранилище",
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            GeneratorMode.entries.forEach { mode ->
                val icon = when (mode) {
                    GeneratorMode.PHONETIC -> Icons.Rounded.RecordVoiceOver
                    GeneratorMode.SMART_WORDS -> Icons.Rounded.TextFields
                    GeneratorMode.RANDOM -> Icons.Rounded.Shuffle
                }
                ExpressiveChip(
                    selected = config.mode == mode,
                    label = mode.title,
                    onClick = {
                        config = config.copy(mode = mode)
                        rollNewPassword(config)
                    },
                    leadingContent = {
                        Icon(imageVector = icon, contentDescription = null, modifier = Modifier.size(16.dp))
                    },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        AnimatedVisibility(
            visible = config.mode == GeneratorMode.SMART_WORDS,
            enter = expandVertically(spring(dampingRatio = 0.7f, stiffness = 360f)) + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            Surface(
                shape = RoundedCornerShape(28.dp),
                color = MaterialTheme.colorScheme.surfaceContainer,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Слово или несколько слов",
                        style = MaterialTheme.typography.titleMedium
                    )
                    OutlinedTextField(
                        value = config.wordInput,
                        onValueChange = { config = config.copy(wordInput = it) },
                        placeholder = {
                            Text("Например: wolf moon или волк ночь")
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(20.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
                            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLowest
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        WordTransformMode.entries.forEach { tm ->
                            ExpressiveChip(
                                selected = config.wordTransformMode == tm,
                                label = tm.title,
                                onClick = {
                                    config = config.copy(wordTransformMode = tm)
                                    rollNewPassword(config)
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    Text(
                        text = config.wordTransformMode.subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Фонетическое окружение", style = MaterialTheme.typography.titleSmall)
                            Text(
                                "Дополняет пароль читаемыми слогами вокруг слов",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        Switch(
                            checked = config.phoneticWordPadding,
                            onCheckedChange = {
                                config = config.copy(phoneticWordPadding = it)
                                rollNewPassword(config)
                            }
                        )
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = config.mode == GeneratorMode.PHONETIC ||
                (config.mode == GeneratorMode.SMART_WORDS && config.phoneticWordPadding),
            enter = expandVertically(spring(dampingRatio = 0.7f, stiffness = 360f)) + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            Surface(
                shape = RoundedCornerShape(28.dp),
                color = MaterialTheme.colorScheme.surfaceContainer,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.AutoAwesome,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "Тонкая настройка фонетики",
                            style = MaterialTheme.typography.titleMedium
                        )
                    }

                    Text(
                        text = "Звучание слогов",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        PhoneticVibe.entries.forEach { vibe ->
                            ExpressiveChip(
                                selected = config.phoneticVibe == vibe,
                                label = vibe.title,
                                onClick = {
                                    config = config.copy(phoneticVibe = vibe)
                                    rollNewPassword(config)
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    Text(
                        text = "Сочетания согласных",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ClusterDensity.entries.forEach { density ->
                            ExpressiveChip(
                                selected = config.clusterDensity == density,
                                label = density.title,
                                onClick = {
                                    config = config.copy(clusterDensity = density)
                                    rollNewPassword(config)
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Аккуратные спецсимволы", style = MaterialTheme.typography.titleSmall)
                            Text(
                                "Ставит читаемые разделители (- _ ! @ #) на стыках слогов",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        Switch(
                            checked = config.readableSeparators,
                            onCheckedChange = {
                                config = config.copy(readableSeparators = it)
                                rollNewPassword(config)
                            }
                        )
                    }
                }
            }
        }

        Surface(
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surfaceContainer,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Длина пароля",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.primaryContainer
                    ) {
                        Text(
                            text = "${config.length}",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp)
                        )
                    }
                }

                Slider(
                    value = config.length.toFloat(),
                    onValueChange = { raw ->
                        val newLen = raw.roundToInt().coerceIn(6, 32)
                        if (newLen != config.length) {
                            config = config.copy(length = newLen)
                        }
                    },
                    onValueChangeFinished = { rollNewPassword(config) },
                    valueRange = 6f..32f,
                    steps = 25,
                    colors = SliderDefaults.colors(
                        thumbColor = MaterialTheme.colorScheme.primary,
                        activeTrackColor = MaterialTheme.colorScheme.primary,
                        inactiveTrackColor = MaterialTheme.colorScheme.surfaceContainerHighest
                    )
                )

                Text(
                    text = "Используемые символы",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    fun toggleOption(newCfg: GeneratorConfig) {
                        if (newCfg.useUppercase || newCfg.useLowercase || newCfg.useDigits || newCfg.useSymbols) {
                            config = newCfg
                            rollNewPassword(newCfg)
                        }
                    }
                    ExpressiveChip(
                        selected = config.useUppercase,
                        label = "A–Z",
                        onClick = { toggleOption(config.copy(useUppercase = !config.useUppercase)) }
                    )
                    ExpressiveChip(
                        selected = config.useLowercase,
                        label = "a–z",
                        onClick = { toggleOption(config.copy(useLowercase = !config.useLowercase)) }
                    )
                    ExpressiveChip(
                        selected = config.useDigits,
                        label = "0–9",
                        onClick = { toggleOption(config.copy(useDigits = !config.useDigits)) }
                    )
                    ExpressiveChip(
                        selected = config.useSymbols,
                        label = "!@#",
                        onClick = { toggleOption(config.copy(useSymbols = !config.useSymbols)) }
                    )
                }
            }
        }
    }
}
