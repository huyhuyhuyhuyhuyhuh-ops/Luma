package com.lumavault.app.generator

import java.security.SecureRandom
import kotlin.math.log2

enum class GeneratorMode(val title: String) {
    PHONETIC("Фонетика"),
    SMART_WORDS("Из слов"),
    RANDOM("Случайный")
}

enum class PhoneticVibe(val title: String) {
    SOFT("Мягкий"),
    BALANCED("Баланс"),
    CRISP("Чёткий")
}

enum class ClusterDensity(val title: String) {
    SIMPLE("Простые"),
    NATURAL("Живые"),
    RICH("Плотные")
}

enum class WordTransformMode(val title: String, val subtitle: String) {
    SMART_ENCRYPT("Зашифровать", "Умная мутация, регистр и связки"),
    EXACT_KEEP("Сохранить точно", "Слово целиком + умное окружение")
}

data class GeneratorConfig(
    val mode: GeneratorMode = GeneratorMode.PHONETIC,
    val length: Int = 16,
    val useUppercase: Boolean = true,
    val useLowercase: Boolean = true,
    val useDigits: Boolean = true,
    val useSymbols: Boolean = true,
    val phoneticVibe: PhoneticVibe = PhoneticVibe.BALANCED,
    val clusterDensity: ClusterDensity = ClusterDensity.NATURAL,
    val readableSeparators: Boolean = true,
    val wordInput: String = "",
    val wordTransformMode: WordTransformMode = WordTransformMode.SMART_ENCRYPT,
    val phoneticWordPadding: Boolean = true
)

data class PasswordStrength(
    val progress: Float,
    val label: String,
    val entropyBits: Int
)

object PasswordGeneratorEngine {

    private val rng = SecureRandom()

    private const val LOWER = "abcdefghijkmnopqrstuvwxyz"
    private const val UPPER = "ABCDEFGHJKLMNPQRSTUVWXYZ"
    private const val DIGITS = "23456789"
    private const val ALL_DIGITS = "0123456789"
    private const val SYMBOLS = "!@#$%^&*_-+=?"
    private const val READABLE_SEPS = "-_!@#&+*"

    private val softOnsets = listOf("l", "m", "n", "s", "v", "r", "f", "h", "w", "y", "sh", "th", "fl", "sl", "sn")
    private val crispOnsets = listOf("k", "t", "d", "g", "b", "p", "z", "v", "r", "x", "kr", "tr", "dr", "gr", "br", "pr", "sk", "st", "sp", "vr", "ch")
    private val singleConsonants = listOf("b", "c", "d", "f", "g", "h", "j", "k", "l", "m", "n", "p", "r", "s", "t", "v", "w", "z")
    private val naturalClusters = listOf(
        "bl", "br", "ch", "cl", "cr", "dr", "fl", "fr", "gl", "gr",
        "kl", "kr", "pl", "pr", "sh", "sk", "sl", "sm", "sn", "sp",
        "st", "sw", "th", "tr", "tw", "vr", "wr"
    )
    private val softCodas = listOf("l", "m", "n", "r", "s")
    private val crispCodas = listOf("k", "t", "n", "r", "s", "x", "nd", "nt", "st", "rk", "lt", "rd")

    private val softVowels = listOf("a", "e", "i", "o", "u", "ea", "ia", "io", "ei")
    private val balancedVowels = listOf("a", "e", "i", "o", "u", "a", "e", "o", "ai", "ou", "ea", "oo")
    private val crispVowels = listOf("a", "e", "i", "o", "u", "y", "au", "oi", "eu")

    private val leetMap = mapOf(
        'a' to listOf("4", "@", "a", "A"),
        'b' to listOf("8", "b", "B"),
        'c' to listOf("(", "c", "C", "k"),
        'e' to listOf("3", "e", "E"),
        'g' to listOf("9", "6", "g", "G"),
        'h' to listOf("#", "h", "H"),
        'i' to listOf("1", "!", "i", "I"),
        'l' to listOf("1", "l", "L"),
        'o' to listOf("0", "o", "O"),
        's' to listOf("5", "$", "s", "S"),
        't' to listOf("7", "+", "t", "T"),
        'z' to listOf("2", "z", "Z")
    )

    private val cyrillicTranslit = mapOf(
        'а' to "a", 'б' to "b", 'в' to "v", 'г' to "g", 'д' to "d", 'е' to "e",
        'ё' to "yo", 'ж' to "zh", 'з' to "z", 'и' to "i", 'й' to "y", 'к' to "k",
        'л' to "l", 'м' to "m", 'н' to "n", 'о' to "o", 'п' to "p", 'р' to "r",
        'с' to "s", 'т' to "t", 'у' to "u", 'ф' to "f", 'х' to "kh", 'ц' to "ts",
        'ч' to "ch", 'ш' to "sh", 'щ' to "sch", 'ъ' to "", 'ы' to "y", 'ь' to "",
        'э' to "e", 'ю' to "yu", 'я' to "ya"
    )

    fun generate(config: GeneratorConfig): String {
        val targetLength = config.length.coerceIn(6, 32)
        return when (config.mode) {
            GeneratorMode.RANDOM -> generateRandom(config, targetLength)
            GeneratorMode.PHONETIC -> generatePhonetic(config, targetLength)
            GeneratorMode.SMART_WORDS -> generateFromWords(config, targetLength)
        }
    }

    private fun generateRandom(config: GeneratorConfig, length: Int): String {
        val pools = mutableListOf<String>()
        if (config.useLowercase) pools += LOWER
        if (config.useUppercase) pools += UPPER
        if (config.useDigits) pools += ALL_DIGITS
        if (config.useSymbols) pools += SYMBOLS
        if (pools.isEmpty()) pools += LOWER

        val allChars = pools.joinToString("")
        val result = CharArray(length)

        var idx = 0
        for (pool in pools) {
            if (idx < length) {
                result[idx++] = pool[rng.nextInt(pool.length)]
            }
        }
        while (idx < length) {
            result[idx++] = allChars[rng.nextInt(allChars.length)]
        }

        for (i in result.lastIndex downTo 1) {
            val j = rng.nextInt(i + 1)
            val tmp = result[i]
            result[i] = result[j]
            result[j] = tmp
        }
        return String(result)
    }

    private fun generateSyllable(vibe: PhoneticVibe, density: ClusterDensity): String {
        val onsetPool = when (density) {
            ClusterDensity.SIMPLE -> when (vibe) {
                PhoneticVibe.SOFT -> listOf("l", "m", "n", "s", "v", "r", "f", "h", "w")
                PhoneticVibe.CRISP -> listOf("k", "t", "d", "g", "b", "p", "z", "v", "r")
                PhoneticVibe.BALANCED -> singleConsonants
            }
            ClusterDensity.NATURAL -> when (vibe) {
                PhoneticVibe.SOFT -> softOnsets
                PhoneticVibe.CRISP -> crispOnsets
                PhoneticVibe.BALANCED -> singleConsonants + naturalClusters.shuffled(rng).take(10)
            }
            ClusterDensity.RICH -> when (vibe) {
                PhoneticVibe.SOFT -> softOnsets + naturalClusters.filter { it.last() in listOf('l', 'r', 'h', 'n') }
                PhoneticVibe.CRISP -> crispOnsets + naturalClusters
                PhoneticVibe.BALANCED -> naturalClusters + singleConsonants
            }
        }

        val vowelPool = when (vibe) {
            PhoneticVibe.SOFT -> softVowels
            PhoneticVibe.BALANCED -> balancedVowels
            PhoneticVibe.CRISP -> crispVowels
        }

        val codaChance = when (density) {
            ClusterDensity.SIMPLE -> 0.20
            ClusterDensity.NATURAL -> 0.45
            ClusterDensity.RICH -> 0.68
        }

        val sb = StringBuilder()
        sb.append(onsetPool[rng.nextInt(onsetPool.size)])
        sb.append(vowelPool[rng.nextInt(vowelPool.size)])

        if (rng.nextDouble() < codaChance) {
            val codas = if (vibe == PhoneticVibe.SOFT) softCodas else crispCodas
            sb.append(codas[rng.nextInt(codas.size)])
        }
        return sb.toString()
    }

    private fun generatePronounceableChunk(
        targetLen: Int,
        vibe: PhoneticVibe,
        density: ClusterDensity,
        capitalizeFirst: Boolean,
        allLower: Boolean,
        allUpper: Boolean
    ): String {
        if (targetLen <= 0) return ""
        val sb = StringBuilder()
        var safety = 0
        while (sb.length < targetLen && safety < 40) {
            safety++
            val syl = generateSyllable(vibe, density)
            if (sb.isNotEmpty() && isConsonant(sb.last()) && syl.length >= 2 && isConsonant(syl[0]) && isConsonant(syl[1])) {
                sb.append(balancedVowels[rng.nextInt(5)])
            }
            sb.append(syl)
        }
        var out = sb.toString().take(targetLen)
        if (out.length >= 2 && isConsonant(out.last()) && isConsonant(out[out.lastIndex - 1])) {
            val softEnd = listOf('a', 'e', 'i', 'o', 'u')[rng.nextInt(5)]
            out = out.dropLast(1) + softEnd
        }

        return when {
            allUpper -> out.uppercase()
            allLower -> out.lowercase()
            capitalizeFirst && out.isNotEmpty() -> out.replaceFirstChar { it.uppercase() }
            else -> out
        }
    }

    private fun generatePhonetic(config: GeneratorConfig, length: Int): String {
        val wantLetters = config.useLowercase || config.useUppercase
        if (!wantLetters) {
            return generateRandom(config, length)
        }

        val allUpper = config.useUppercase && !config.useLowercase
        val allLower = config.useLowercase && !config.useUppercase

        val parts = mutableListOf<String>()
        val extraTokens = mutableListOf<String>()
        if (config.useDigits && length >= 8) {
            val digitCount = if (length >= 16) rng.nextInt(2) + 2 else rng.nextInt(2) + 1
            extraTokens += buildString {
                repeat(digitCount) { append(DIGITS[rng.nextInt(DIGITS.length)]) }
            }
        }
        if (config.useSymbols && length >= 8) {
            val symPool = if (config.readableSeparators) READABLE_SEPS else SYMBOLS
            extraTokens += symPool[rng.nextInt(symPool.length)].toString()
            if (length >= 20 && rng.nextBoolean()) {
                extraTokens += symPool[rng.nextInt(symPool.length)].toString()
            }
        }

        val extraTotalLen = extraTokens.sumOf { it.length }
        val letterBudget = (length - extraTotalLen).coerceAtLeast(4)

        val chunkCount = when {
            letterBudget <= 8 -> 1
            letterBudget <= 15 -> 2
            letterBudget <= 23 -> 3
            else -> 4
        }

        val chunkLengths = IntArray(chunkCount) { letterBudget / chunkCount }
        var leftover = letterBudget % chunkCount
        var ci = 0
        while (leftover > 0) {
            chunkLengths[ci % chunkCount]++
            leftover--
            ci++
        }

        val wordChunks = chunkLengths.mapIndexed { index, len ->
            val cap = config.useUppercase && config.useLowercase && (index == 0 || rng.nextDouble() < 0.7)
            generatePronounceableChunk(
                targetLen = len,
                vibe = config.phoneticVibe,
                density = config.clusterDensity,
                capitalizeFirst = cap,
                allLower = allLower,
                allUpper = allUpper
            )
        }

        val shuffledExtras = extraTokens.shuffled(rng).toMutableList()
        for (i in wordChunks.indices) {
            parts += wordChunks[i]
            if (shuffledExtras.isNotEmpty() && (i < wordChunks.lastIndex || rng.nextBoolean())) {
                parts += shuffledExtras.removeAt(0)
            }
        }
        while (shuffledExtras.isNotEmpty()) {
            val pos = rng.nextInt(parts.size + 1)
            parts.add(pos, shuffledExtras.removeAt(0))
        }

        var result = parts.joinToString("")
        if (result.length > length) result = result.take(length)
        while (result.length < length) {
            val pad = if (config.useDigits && rng.nextBoolean()) {
                DIGITS[rng.nextInt(DIGITS.length)].toString()
            } else {
                generatePronounceableChunk(1, config.phoneticVibe, ClusterDensity.SIMPLE, false, allLower, allUpper)
            }
            result += pad
        }
        return result.take(length)
    }

    private fun transliterateWord(raw: String): String {
        val sb = StringBuilder()
        for (ch in raw.trim()) {
            val lower = ch.lowercaseChar()
            val mapped = cyrillicTranslit[lower]
            if (mapped != null) {
                sb.append(if (ch.isUpperCase()) mapped.replaceFirstChar { it.uppercase() } else mapped)
            } else if (ch.isLetterOrDigit()) {
                sb.append(ch)
            }
        }
        return sb.toString()
    }

    private fun smartObfuscateWord(word: String, config: GeneratorConfig): String {
        if (word.isEmpty()) return ""
        val sb = StringBuilder()
        var mutatedCount = 0
        val chars = word.toCharArray()
        for (i in chars.indices) {
            val ch = chars[i]
            val lower = ch.lowercaseChar()
            val candidates = leetMap[lower]?.filter { cand ->
                val c = cand[0]
                when {
                    c.isDigit() -> config.useDigits
                    !c.isLetterOrDigit() -> config.useSymbols
                    c.isUpperCase() -> config.useUppercase
                    else -> config.useLowercase
                }
            }

            val shouldMutate = candidates != null && candidates.isNotEmpty() &&
                (rng.nextDouble() < 0.48 || (i == chars.lastIndex && mutatedCount == 0))

            if (shouldMutate && candidates != null) {
                val nonIdentity = candidates.filter { !it.equals(ch.toString(), ignoreCase = true) }
                val pick = if (nonIdentity.isNotEmpty() && rng.nextDouble() < 0.72) {
                    nonIdentity[rng.nextInt(nonIdentity.size)]
                } else {
                    candidates[rng.nextInt(candidates.size)]
                }
                sb.append(pick)
                mutatedCount++
            } else {
                val styled = when {
                    config.useUppercase && !config.useLowercase -> ch.uppercaseChar()
                    config.useLowercase && !config.useUppercase -> ch.lowercaseChar()
                    i == 0 && config.useUppercase -> ch.uppercaseChar()
                    rng.nextDouble() < 0.25 && config.useUppercase -> ch.uppercaseChar()
                    else -> ch.lowercaseChar()
                }
                sb.append(styled)
            }
        }
        return sb.toString()
    }

    private fun generateFromWords(config: GeneratorConfig, length: Int): String {
        val rawWords = config.wordInput
            .split(Regex("[\\s,;]+"))
            .map { transliterateWord(it) }
            .filter { it.isNotEmpty() }

        if (rawWords.isEmpty()) {
            return generatePhonetic(config, length)
        }

        val allUpper = config.useUppercase && !config.useLowercase
        val allLower = config.useLowercase && !config.useUppercase

        val processedWords = when (config.wordTransformMode) {
            WordTransformMode.EXACT_KEEP -> {
                rawWords.map { w ->
                    when {
                        allUpper -> w.uppercase()
                        allLower -> w.lowercase()
                        else -> w
                    }
                }
            }
            WordTransformMode.SMART_ENCRYPT -> {
                val ordered = if (rawWords.size > 1 && rng.nextBoolean()) {
                    rawWords.shuffled(rng)
                } else {
                    rawWords
                }
                ordered.map { smartObfuscateWord(it, config) }
            }
        }

        fun randomBridge(maxLen: Int): String {
            if (maxLen <= 0) return ""
            val sb = StringBuilder()
            if (config.useSymbols && sb.length < maxLen && rng.nextDouble() < 0.75) {
                val pool = if (config.readableSeparators) READABLE_SEPS else SYMBOLS
                sb.append(pool[rng.nextInt(pool.length)])
            }
            if (config.useDigits && sb.length < maxLen && rng.nextDouble() < 0.8) {
                sb.append(DIGITS[rng.nextInt(DIGITS.length)])
            }
            if (sb.isEmpty()) {
                sb.append(
                    if (config.useDigits) DIGITS[rng.nextInt(DIGITS.length)]
                    else if (config.useSymbols) READABLE_SEPS[rng.nextInt(READABLE_SEPS.length)]
                    else listOf('a', 'e', 'i', 'o', 'u')[rng.nextInt(5)]
                )
            }
            return sb.toString().take(maxLen)
        }

        val coreBuilder = StringBuilder()
        for (i in processedWords.indices) {
            val w = processedWords[i]
            if (i > 0 && coreBuilder.length < length) {
                val roomLeftForRest = length - coreBuilder.length - processedWords.drop(i).sumOf { it.length }
                if (roomLeftForRest >= 1) {
                    coreBuilder.append(randomBridge(roomLeftForRest.coerceAtMost(2)))
                }
            }
            coreBuilder.append(w)
        }

        var core = coreBuilder.toString()

        if (core.length > length) {
            if (config.wordTransformMode == WordTransformMode.EXACT_KEEP) {
                core = core.take(length)
            } else {
                val perWord = (length - (processedWords.size - 1)).coerceAtLeast(2) / processedWords.size
                val compact = processedWords.map { it.take(perWord.coerceAtLeast(2)) }
                val sep = if (config.useSymbols) READABLE_SEPS[rng.nextInt(READABLE_SEPS.length)].toString()
                else if (config.useDigits) DIGITS[rng.nextInt(DIGITS.length)].toString()
                else ""
                core = compact.joinToString(sep).take(length)
            }
        }

        val remaining = length - core.length
        if (remaining <= 0) return core.take(length)

        val prefixLen = when {
            remaining <= 2 -> if (rng.nextBoolean()) remaining else 0
            else -> rng.nextInt(remaining + 1)
        }
        val suffixLen = remaining - prefixLen

        fun buildPadding(len: Int): String {
            if (len <= 0) return ""
            val sb = StringBuilder()
            if (config.phoneticWordPadding && (config.useLowercase || config.useUppercase)) {
                var left = len
                if (left >= 2 && config.useSymbols && rng.nextDouble() < 0.65) {
                    sb.append(READABLE_SEPS[rng.nextInt(READABLE_SEPS.length)])
                    left--
                }
                if (left >= 3 && config.useDigits && rng.nextDouble() < 0.75) {
                    val dCount = if (left >= 6) 2 else 1
                    repeat(dCount) { sb.append(DIGITS[rng.nextInt(DIGITS.length)]) }
                    left -= dCount
                }
                if (left > 0) {
                    sb.append(
                        generatePronounceableChunk(
                            targetLen = left,
                            vibe = config.phoneticVibe,
                            density = config.clusterDensity,
                            capitalizeFirst = config.useUppercase && config.useLowercase,
                            allLower = allLower,
                            allUpper = allUpper
                        )
                    )
                }
            } else {
                sb.append(generateRandom(config, len))
            }
            return sb.toString().take(len)
        }

        val prefix = buildPadding(prefixLen)
        val suffix = buildPadding(suffixLen)
        var finalPass = (prefix + core + suffix).take(length)

        if (config.wordTransformMode == WordTransformMode.SMART_ENCRYPT && finalPass.length >= 6) {
            if (config.useDigits && finalPass.none { it.isDigit() }) {
                val pos = rng.nextInt(finalPass.length)
                finalPass = finalPass.replaceRange(pos, pos + 1, DIGITS[rng.nextInt(DIGITS.length)].toString())
            }
            if (config.useSymbols && finalPass.none { !it.isLetterOrDigit() }) {
                val pos = rng.nextInt(finalPass.length)
                finalPass = finalPass.replaceRange(pos, pos + 1, READABLE_SEPS[rng.nextInt(READABLE_SEPS.length)].toString())
            }
        }

        return finalPass
    }

    fun evaluateStrength(password: String): PasswordStrength {
        if (password.isEmpty()) return PasswordStrength(0f, "Пусто", 0)
        var charsetSize = 0
        if (password.any { it.isLowerCase() }) charsetSize += 26
        if (password.any { it.isUpperCase() }) charsetSize += 26
        if (password.any { it.isDigit() }) charsetSize += 10
        if (password.any { !it.isLetterOrDigit() }) charsetSize += 24
        if (charsetSize == 0) charsetSize = 26

        val uniqueRatio = password.toSet().size.toDouble() / password.length.toDouble()
        val effectiveLen = password.length * (0.65 + 0.35 * uniqueRatio)
        val bits = (effectiveLen * log2(charsetSize.toDouble())).toInt().coerceAtLeast(0)

        val (progress, label) = when {
            bits < 36 -> 0.22f to "Слабый"
            bits < 56 -> 0.50f to "Нормальный"
            bits < 80 -> 0.78f to "Надёжный"
            else -> 1.0f to "Бронебойный"
        }
        return PasswordStrength(progress, label, bits)
    }

    private fun isConsonant(c: Char): Boolean {
        val l = c.lowercaseChar()
        return l in 'a'..'z' && l !in setOf('a', 'e', 'i', 'o', 'u', 'y')
    }
}
