package com.lumavault.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.spring
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Casino
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lumavault.app.data.SecurityConfig
import com.lumavault.app.data.VaultCategories
import com.lumavault.app.data.VaultEntry
import com.lumavault.app.generator.GeneratorConfig
import com.lumavault.app.generator.GeneratorMode
import com.lumavault.app.generator.PasswordGeneratorEngine
import com.lumavault.app.ui.components.ExpressiveButton
import com.lumavault.app.ui.components.ExpressiveChip
import com.lumavault.app.ui.components.ExpressiveIconButton
import com.lumavault.app.ui.components.colorizePassword
import com.lumavault.app.ui.components.expressiveCookieShape
import com.lumavault.app.ui.components.rememberExpressivePressState

@Composable
fun VaultScreen(
    entries: List<VaultEntry>,
    onAddClick: () -> Unit,
    onEditEntry: (VaultEntry) -> Unit,
    onDeleteEntry: (VaultEntry) -> Unit,
    onToggleFavorite: (VaultEntry) -> Unit,
    onCopyText: (label: String, value: String) -> Unit,
    onLockNow: () -> Unit,
    onOpenSecurityInfo: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Все") }
    var expandedId by remember { mutableStateOf<String?>(null) }
    var pendingDelete by remember { mutableStateOf<VaultEntry?>(null) }

    val filteredEntries = remember(entries, query, selectedCategory) {
        entries
            .filter { entry ->
                val matchesCategory = selectedCategory == "Все" || entry.category == selectedCategory
                val q = query.trim()
                val matchesQuery = q.isEmpty() ||
                    entry.title.contains(q, ignoreCase = true) ||
                    entry.username.contains(q, ignoreCase = true) ||
                    entry.notes.contains(q, ignoreCase = true)
                matchesCategory && matchesQuery
            }
            .sortedWith(compareByDescending<VaultEntry> { it.isFavorite }.thenByDescending { it.updatedAt })
    }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 18.dp,
                end = 18.dp,
                top = 12.dp,
                bottom = 120.dp
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item(key = "header") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "Хранилище",
                                style = MaterialTheme.typography.headlineMedium
                            )
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = MaterialTheme.colorScheme.primaryContainer
                            ) {
                                Text(
                                    text = "${entries.size}",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                                )
                            }
                        }
                        Text(
                            text = "Локальная песочница • AES-256-GCM",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ExpressiveIconButton(
                            onClick = onOpenSecurityInfo,
                            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                            contentColor = MaterialTheme.colorScheme.primary
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Security,
                                contentDescription = "Безопасность",
                                modifier = Modifier.size(21.dp)
                            )
                        }
                        ExpressiveIconButton(
                            onClick = onLockNow,
                            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                            contentColor = MaterialTheme.colorScheme.onSurface
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Lock,
                                contentDescription = "Заблокировать",
                                modifier = Modifier.size(21.dp)
                            )
                        }
                    }
                }
            }

            item(key = "search") {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Поиск сервиса или логина...") },
                    leadingIcon = {
                        Icon(Icons.Rounded.Search, contentDescription = null)
                    },
                    trailingIcon = {
                        if (query.isNotEmpty()) {
                            IconButton(onClick = { query = "" }) {
                                Icon(Icons.Rounded.Close, contentDescription = "Очистить")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(26.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surfaceContainer,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainer,
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.surfaceContainerHigh
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            item(key = "categories") {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(VaultCategories.ALL) { cat ->
                        ExpressiveChip(
                            selected = selectedCategory == cat,
                            label = cat,
                            onClick = { selectedCategory = cat }
                        )
                    }
                }
            }

            if (filteredEntries.isEmpty()) {
                item(key = "empty") {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 46.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(86.dp)
                                .clip(expressiveCookieShape(lobes = 8, depth = 0.08f))
                                .background(MaterialTheme.colorScheme.surfaceContainerHigh),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Key,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                        Text(
                            text = if (entries.isEmpty()) "Пока нет паролей" else "Ничего не найдено",
                            style = MaterialTheme.typography.titleLarge
                        )
                        Text(
                            text = if (entries.isEmpty())
                                "Добавьте первую запись или сразу сгенерируйте красивый и надёжный пароль."
                            else "Попробуйте изменить запрос или выбрать другую категорию.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 24.dp)
                        )
                        if (entries.isEmpty()) {
                            Spacer(Modifier.height(4.dp))
                            ExpressiveButton(onClick = onAddClick) {
                                Icon(Icons.Rounded.Add, contentDescription = null)
                                Text("Добавить пароль")
                            }
                        }
                    }
                }
            } else {
                items(filteredEntries, key = { it.id }) { entry ->
                    VaultEntryCard(
                        entry = entry,
                        expanded = expandedId == entry.id,
                        onToggleExpand = {
                            expandedId = if (expandedId == entry.id) null else entry.id
                        },
                        onToggleFavorite = { onToggleFavorite(entry) },
                        onCopyPassword = { onCopyText("Пароль", entry.password) },
                        onCopyUsername = { onCopyText("Логин", entry.username) },
                        onEdit = { onEditEntry(entry) },
                        onDelete = { pendingDelete = entry }
                    )
                }
            }
        }

        ExpressiveButton(
            onClick = onAddClick,
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            defaultCorner = 24.dp,
            pressedCorner = 14.dp,
            pressScale = 1.09f,
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 20.dp, bottom = 104.dp)
        ) {
            Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(22.dp))
            Text("Добавить", style = MaterialTheme.typography.labelLarge)
        }
    }

    pendingDelete?.let { entryToDelete ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            shape = RoundedCornerShape(30.dp),
            title = { Text("Удалить запись?") },
            text = {
                Text("Пароль для «${entryToDelete.title}» будет удалён без возможности восстановления.")
            },
            confirmButton = {
                ExpressiveButton(
                    onClick = {
                        onDeleteEntry(entryToDelete)
                        pendingDelete = null
                    },
                    containerColor = MaterialTheme.colorScheme.error,
                    contentColor = MaterialTheme.colorScheme.onError,
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    Text("Удалить")
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingDelete = null }) {
                    Text("Отмена")
                }
            }
        )
    }
}

@Composable
private fun VaultEntryCard(
    entry: VaultEntry,
    expanded: Boolean,
    onToggleExpand: () -> Unit,
    onToggleFavorite: () -> Unit,
    onCopyPassword: () -> Unit,
    onCopyUsername: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    var passwordVisible by remember(entry.id) { mutableStateOf(false) }
    val interactionSource = remember { MutableInteractionSource() }
    val (scale, corner) = rememberExpressivePressState(
        interactionSource = interactionSource,
        pressScale = 1.025f,
        defaultCorner = 26.dp,
        pressedCorner = 18.dp
    )

    Surface(
        shape = RoundedCornerShape(corner),
        color = MaterialTheme.colorScheme.surfaceContainer,
        tonalElevation = if (expanded) 4.dp else 1.dp,
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .animateContentSize(spring(dampingRatio = 0.65f, stiffness = 360f))
            .clip(RoundedCornerShape(corner))
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onToggleExpand
            )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = entry.title.trim().take(2).uppercase().ifEmpty { "PW" },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }

                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = entry.title,
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (entry.isFavorite) {
                            Icon(
                                imageVector = Icons.Rounded.Star,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.tertiary,
                                modifier = Modifier.size(15.dp)
                            )
                        }
                    }
                    Text(
                        text = entry.username.ifBlank { entry.category },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                ExpressiveIconButton(
                    onClick = onCopyPassword,
                    containerColor = MaterialTheme.colorScheme.secondaryContainer,
                    contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
                    modifier = Modifier.size(42.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.ContentCopy,
                        contentDescription = "Копировать пароль",
                        modifier = Modifier.size(18.dp)
                    )
                }

                Icon(
                    imageVector = if (expanded) Icons.Rounded.KeyboardArrowUp else Icons.Rounded.KeyboardArrowDown,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            AnimatedVisibility(
                visible = expanded,
                enter = expandVertically(spring(dampingRatio = 0.72f, stiffness = 360f)) + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column(
                    modifier = Modifier.padding(top = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerLowest,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            if (passwordVisible) {
                                Text(
                                    text = colorizePassword(entry.password),
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 15.sp,
                                    modifier = Modifier.weight(1f)
                                )
                            } else {
                                Text(
                                    text = "•".repeat(entry.password.length.coerceIn(6, 20)),
                                    fontSize = 17.sp,
                                    letterSpacing = 2.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(
                                    imageVector = if (passwordVisible) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                                    contentDescription = "Показать пароль"
                                )
                            }
                        }
                    }

                    if (entry.notes.isNotBlank()) {
                        Text(
                            text = entry.notes,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (entry.username.isNotBlank()) {
                            ExpressiveButton(
                                onClick = onCopyUsername,
                                containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                                contentColor = MaterialTheme.colorScheme.onSurface,
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 9.dp)
                            ) {
                                Icon(Icons.Rounded.ContentCopy, null, Modifier.size(16.dp))
                                Text("Логин", style = MaterialTheme.typography.labelMedium)
                            }
                        }
                        Spacer(Modifier.weight(1f))
                        ExpressiveIconButton(
                            onClick = onToggleFavorite,
                            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                            contentColor = if (entry.isFavorite) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(40.dp)
                        ) {
                            Icon(
                                imageVector = if (entry.isFavorite) Icons.Rounded.Star else Icons.Rounded.StarBorder,
                                contentDescription = "Избранное",
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        ExpressiveIconButton(
                            onClick = onEdit,
                            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                            contentColor = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(40.dp)
                        ) {
                            Icon(Icons.Rounded.Edit, contentDescription = "Редактировать", modifier = Modifier.size(18.dp))
                        }
                        ExpressiveIconButton(
                            onClick = onDelete,
                            containerColor = MaterialTheme.colorScheme.errorContainer,
                            contentColor = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.size(40.dp)
                        ) {
                            Icon(Icons.Rounded.Delete, contentDescription = "Удалить", modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun VaultEntryEditorSheet(
    initialEntry: VaultEntry?,
    prefilledPassword: String?,
    onDismiss: () -> Unit,
    onSave: (title: String, username: String, password: String, category: String, notes: String) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var title by remember(initialEntry) { mutableStateOf(initialEntry?.title ?: "") }
    var username by remember(initialEntry) { mutableStateOf(initialEntry?.username ?: "") }
    var password by remember(initialEntry, prefilledPassword) {
        mutableStateOf(initialEntry?.password ?: prefilledPassword ?: "")
    }
    var category by remember(initialEntry) { mutableStateOf(initialEntry?.category ?: "Общее") }
    var notes by remember(initialEntry) { mutableStateOf(initialEntry?.notes ?: "") }
    var showPass by remember { mutableStateOf(true) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        shape = RoundedCornerShape(topStart = 34.dp, topEnd = 34.dp),
        containerColor = MaterialTheme.colorScheme.surfaceContainerLow
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = if (initialEntry == null) "Новая запись" else "Редактировать запись",
                style = MaterialTheme.typography.headlineSmall
            )

            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Сервис или сайт *") },
                singleLine = true,
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = username,
                onValueChange = { username = it },
                label = { Text("Логин / Email / Ник") },
                singleLine = true,
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Пароль *") },
                singleLine = true,
                visualTransformation = if (showPass) VisualTransformation.None else PasswordVisualTransformation(),
                shape = RoundedCornerShape(20.dp),
                trailingIcon = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = {
                            password = PasswordGeneratorEngine.generate(
                                GeneratorConfig(mode = GeneratorMode.PHONETIC, length = 16)
                            )
                        }) {
                            Icon(
                                imageVector = Icons.Rounded.Casino,
                                contentDescription = "Быстро сгенерировать",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                        IconButton(onClick = { showPass = !showPass }) {
                            Icon(
                                imageVector = if (showPass) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                                contentDescription = null
                            )
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )

            Text(
                text = "Категория",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                VaultCategories.EDITABLE.forEach { cat ->
                    ExpressiveChip(
                        selected = category == cat,
                        label = cat,
                        onClick = { category = cat }
                    )
                }
            }

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Заметка (необязательно)") },
                minLines = 2,
                maxLines = 4,
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(4.dp))

            ExpressiveButton(
                onClick = {
                    if (title.isNotBlank() && password.isNotBlank()) {
                        onSave(title.trim(), username.trim(), password, category, notes.trim())
                    }
                },
                enabled = title.isNotBlank() && password.isNotBlank(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = if (initialEntry == null) "Зашифровать и сохранить" else "Сохранить изменения",
                    style = MaterialTheme.typography.titleMedium
                )
            }
        }
    }
}

@Composable
fun SecurityInfoDialog(
    vaultPath: String,
    encryptionStatus: String,
    biometricAvailable: Boolean,
    config: SecurityConfig?,
    onToggleBiometric: (Boolean) -> Unit,
    onToggleAutoLock: (Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(32.dp),
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(Icons.Rounded.Security, null, tint = MaterialTheme.colorScheme.primary)
                Text("Изоляция и защита")
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerHigh
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text("Шифрование", style = MaterialTheme.typography.labelLarge)
                        Text(encryptionStatus, style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(2.dp))
                        Text("Приватная папка (sandbox)", style = MaterialTheme.typography.labelLarge)
                        Text(
                            text = vaultPath,
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = "• Доступ закрыт для всех сторонних приложений (UID sandbox)\n• Нет разрешения на интернет (100% оффлайн)\n• Облачные бэкапы и скриншоты заблокированы\n• Папка удаляется автоматически при удалении приложения",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                if (config != null) {
                    if (biometricAvailable) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Вход по отпечатку", style = MaterialTheme.typography.bodyLarge)
                            Switch(
                                checked = config.biometricEnabled,
                                onCheckedChange = onToggleBiometric
                            )
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Автоблокировка", style = MaterialTheme.typography.bodyLarge)
                            Text(
                                "Блокировать при сворачивании",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        Switch(
                            checked = config.autoLockOnBackground,
                            onCheckedChange = onToggleAutoLock
                        )
                    }
                }
            }
        },
        confirmButton = {
            ExpressiveButton(
                onClick = onDismiss,
                contentPadding = PaddingValues(horizontal = 18.dp, vertical = 10.dp)
            ) {
                Text("Понятно")
            }
        }
    )
}
