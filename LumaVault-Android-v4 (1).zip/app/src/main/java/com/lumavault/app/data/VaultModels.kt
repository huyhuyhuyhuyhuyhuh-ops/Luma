package com.lumavault.app.data

import kotlinx.serialization.Serializable
import java.util.UUID

@Serializable
data class VaultEntry(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val username: String,
    val password: String,
    val category: String = "Общее",
    val notes: String = "",
    val isFavorite: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Serializable
data class VaultPayload(
    val version: Int = 1,
    val entries: List<VaultEntry> = emptyList()
)

@Serializable
data class SecurityConfig(
    val pinHashBase64: String,
    val pinSaltBase64: String,
    val pinLength: Int = 4,
    val biometricEnabled: Boolean = true,
    val autoLockOnBackground: Boolean = true
)

object VaultCategories {
    val ALL = listOf(
        "Все",
        "Соцсети",
        "Почта",
        "Финансы",
        "Игры",
        "Работа",
        "Общее"
    )
    val EDITABLE = ALL.drop(1)
}
