package com.lumavault.app

import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.PersistableBundle
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.lumavault.app.data.SecureVaultStorage
import com.lumavault.app.data.SecurityConfig
import com.lumavault.app.data.VaultEntry
import com.lumavault.app.security.BiometricHelper
import com.lumavault.app.ui.components.rememberExpressivePressState
import com.lumavault.app.ui.screens.GeneratorScreen
import com.lumavault.app.ui.screens.LockScreen
import com.lumavault.app.ui.screens.SecurityInfoDialog
import com.lumavault.app.ui.screens.VaultEntryEditorSheet
import com.lumavault.app.ui.screens.VaultScreen
import com.lumavault.app.ui.theme.LumaVaultTheme
import kotlinx.coroutines.launch

class MainActivity : FragmentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )
        enableEdgeToEdge()

        val storage = SecureVaultStorage(applicationContext)

        setContent {
            LumaVaultTheme {
                LumaVaultApp(storage = storage)
            }
        }
    }
}

private enum class AppTab(val title: String, val icon: ImageVector) {
    VAULT("Хранилище", Icons.Rounded.Key),
    GENERATOR("Генератор", Icons.Rounded.AutoAwesome)
}

@Composable
private fun LumaVaultApp(storage: SecureVaultStorage) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    var securityConfig by remember { mutableStateOf<SecurityConfig?>(storage.loadSecurityConfig()) }
    var isSetupMode by remember { mutableStateOf(!storage.isPinConfigured()) }
    var isUnlocked by remember { mutableStateOf(false) }

    var entries by remember { mutableStateOf<List<VaultEntry>>(emptyList()) }
    var selectedTab by remember { mutableIntStateOf(0) }

    var showEditorSheet by remember { mutableStateOf(false) }
    var editingEntry by remember { mutableStateOf<VaultEntry?>(null) }
    var prefilledPassword by remember { mutableStateOf<String?>(null) }
    var showSecurityDialog by remember { mutableStateOf(false) }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, securityConfig) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP &&
                isUnlocked &&
                (securityConfig?.autoLockOnBackground != false)
            ) {
                isUnlocked = false
                entries = emptyList()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    fun copySecurely(label: String, text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            clip.description.extras = PersistableBundle().apply {
                putBoolean(ClipDescription.EXTRA_IS_SENSITIVE, true)
            }
        }
        clipboard.setPrimaryClip(clip)
        scope.launch {
            snackbarHostState.currentSnackbarData?.dismiss()
            snackbarHostState.showSnackbar("$label скопирован (скрыто из превью)")
        }
    }

    fun unlockAndLoad() {
        entries = storage.loadEntries()
        isUnlocked = true
    }

    AnimatedContent(
        targetState = isUnlocked,
        transitionSpec = {
            (fadeIn(tween(280)) + scaleIn(
                initialScale = 0.94f,
                animationSpec = spring(dampingRatio = 0.72f, stiffness = 360f)
            )) togetherWith (fadeOut(tween(180)) + scaleOut(targetScale = 1.04f))
        },
        label = "app_lock_transition"
    ) { unlocked ->
        if (!unlocked) {
            LockScreen(
                isSetupMode = isSetupMode,
                securityConfig = securityConfig,
                onSetupComplete = { pin, enableBio ->
                    val cfg = storage.setupPin(pin, enableBio)
                    securityConfig = cfg
                    isSetupMode = false
                    unlockAndLoad()
                },
                onVerifyPin = { pin -> storage.verifyPin(pin) },
                onUnlocked = { unlockAndLoad() }
            )
        } else {
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                snackbarHost = {
                    SnackbarHost(
                        hostState = snackbarHostState,
                        modifier = Modifier.padding(bottom = 86.dp)
                    )
                }
            ) { _ ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding()
                ) {
                    AnimatedContent(
                        targetState = selectedTab,
                        transitionSpec = {
                            val dir = if (targetState > initialState) 1 else -1
                            (slideInHorizontally(
                                animationSpec = spring(dampingRatio = 0.76f, stiffness = 380f)
                            ) { width -> dir * (width / 4) } + fadeIn(tween(220))) togetherWith
                                (slideOutHorizontally(tween(160)) { width -> -dir * (width / 4) } + fadeOut(tween(150)))
                        },
                        label = "tab_content"
                    ) { tab ->
                        when (tab) {
                            0 -> VaultScreen(
                                entries = entries,
                                onAddClick = {
                                    editingEntry = null
                                    prefilledPassword = null
                                    showEditorSheet = true
                                },
                                onEditEntry = { entry ->
                                    editingEntry = entry
                                    prefilledPassword = null
                                    showEditorSheet = true
                                },
                                onDeleteEntry = { entry ->
                                    val updated = entries.filterNot { it.id == entry.id }
                                    entries = updated
                                    storage.saveEntries(updated)
                                },
                                onToggleFavorite = { entry ->
                                    val updated = entries.map {
                                        if (it.id == entry.id) it.copy(isFavorite = !it.isFavorite) else it
                                    }
                                    entries = updated
                                    storage.saveEntries(updated)
                                },
                                onCopyText = { label, value -> copySecurely(label, value) },
                                onLockNow = {
                                    isUnlocked = false
                                    entries = emptyList()
                                },
                                onOpenSecurityInfo = { showSecurityDialog = true }
                            )
                            else -> GeneratorScreen(
                                onCopyPassword = { pass -> copySecurely("Пароль", pass) },
                                onSaveToVault = { pass ->
                                    editingEntry = null
                                    prefilledPassword = pass
                                    showEditorSheet = true
                                }
                            )
                        }
                    }

                    ExpressiveFloatingNavBar(
                        selectedIndex = selectedTab,
                        onSelect = { selectedTab = it },
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .navigationBarsPadding()
                            .padding(bottom = 14.dp)
                    )
                }
            }

            if (showEditorSheet) {
                VaultEntryEditorSheet(
                    initialEntry = editingEntry,
                    prefilledPassword = prefilledPassword,
                    onDismiss = { showEditorSheet = false },
                    onSave = { title, username, password, category, notes ->
                        val now = System.currentTimeMillis()
                        val updated = if (editingEntry == null) {
                            entries + VaultEntry(
                                title = title,
                                username = username,
                                password = password,
                                category = category,
                                notes = notes,
                                createdAt = now,
                                updatedAt = now
                            )
                        } else {
                            entries.map {
                                if (it.id == editingEntry!!.id) {
                                    it.copy(
                                        title = title,
                                        username = username,
                                        password = password,
                                        category = category,
                                        notes = notes,
                                        updatedAt = now
                                    )
                                } else it
                            }
                        }
                        entries = updated
                        storage.saveEntries(updated)
                        showEditorSheet = false
                        selectedTab = 0
                        scope.launch {
                            snackbarHostState.showSnackbar("Зашифровано и сохранено")
                        }
                    }
                )
            }

            if (showSecurityDialog) {
                SecurityInfoDialog(
                    vaultPath = storage.vaultDirectory.absolutePath,
                    encryptionStatus = storage.getHardwareSecurityInfo(),
                    biometricAvailable = BiometricHelper.isAvailable(context),
                    config = securityConfig,
                    onToggleBiometric = { enabled ->
                        securityConfig?.let { cfg ->
                            val updated = cfg.copy(biometricEnabled = enabled)
                            storage.saveSecurityConfig(updated)
                            securityConfig = updated
                        }
                    },
                    onToggleAutoLock = { enabled ->
                        securityConfig?.let { cfg ->
                            val updated = cfg.copy(autoLockOnBackground = enabled)
                            storage.saveSecurityConfig(updated)
                            securityConfig = updated
                        }
                    },
                    onDismiss = { showSecurityDialog = false }
                )
            }
        }
    }
}

@Composable
private fun ExpressiveFloatingNavBar(
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(32.dp),
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        tonalElevation = 8.dp,
        shadowElevation = 10.dp,
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AppTab.entries.forEachIndexed { index, tab ->
                val selected = selectedIndex == index
                val haptic = LocalHapticFeedback.current
                val interactionSource = remember { MutableInteractionSource() }
                val (scale, _) = rememberExpressivePressState(
                    interactionSource = interactionSource,
                    pressScale = 1.08f
                )
                val bg by animateColorAsState(
                    targetValue = if (selected) MaterialTheme.colorScheme.primaryContainer
                    else MaterialTheme.colorScheme.surfaceContainerHigh,
                    animationSpec = spring(stiffness = Spring.StiffnessMedium),
                    label = "nav_bg"
                )
                val fg by animateColorAsState(
                    targetValue = if (selected) MaterialTheme.colorScheme.onPrimaryContainer
                    else MaterialTheme.colorScheme.onSurfaceVariant,
                    label = "nav_fg"
                )
                val horizPad by animateDpAsState(
                    targetValue = if (selected) 20.dp else 16.dp,
                    animationSpec = spring(dampingRatio = 0.55f, stiffness = 420f),
                    label = "nav_pad"
                )

                Surface(
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onSelect(index)
                    },
                    interactionSource = interactionSource,
                    shape = RoundedCornerShape(26.dp),
                    color = bg,
                    contentColor = fg,
                    modifier = Modifier.graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                    }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = horizPad, vertical = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = tab.icon,
                            contentDescription = tab.title,
                            modifier = Modifier.size(21.dp)
                        )
                        Text(
                            text = tab.title,
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
            }
        }
    }
}
