package com.lumavault.app.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

fun expressiveCookieShape(lobes: Int = 10, depth: Float = 0.085f): Shape = GenericShape { size, _ ->
    val cx = size.width / 2f
    val cy = size.height / 2f
    val maxR = min(cx, cy)
    val steps = 160
    for (i in 0..steps) {
        val theta = (2.0 * PI * i / steps)
        val r = maxR * (1f - depth + depth * cos(lobes * theta).toFloat())
        val x = cx + r * cos(theta).toFloat()
        val y = cy + r * sin(theta).toFloat()
        if (i == 0) moveTo(x, y) else lineTo(x, y)
    }
    close()
}

@Composable
fun rememberExpressivePressState(
    interactionSource: MutableInteractionSource,
    pressScale: Float = 1.07f,
    defaultCorner: Dp = 26.dp,
    pressedCorner: Dp = 14.dp
): Pair<Float, Dp> {
    val isPressed by interactionSource.collectIsPressedAsState()
    var tapPulse by remember { mutableStateOf(false) }

    LaunchedEffect(isPressed) {
        if (isPressed) {
            tapPulse = true
        } else if (tapPulse) {
            delay(145L)
            tapPulse = false
        }
    }

    val active = isPressed || tapPulse

    val scale by animateFloatAsState(
        targetValue = if (active) pressScale else 1f,
        animationSpec = spring(
            dampingRatio = 0.48f,
            stiffness = 460f
        ),
        label = "md3e_scale"
    )

    val corner by animateDpAsState(
        targetValue = if (active) pressedCorner else defaultCorner,
        animationSpec = spring(
            dampingRatio = 0.56f,
            stiffness = 420f
        ),
        label = "md3e_corner"
    )

    return scale to corner
}

@Composable
fun ExpressiveButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    containerColor: Color = MaterialTheme.colorScheme.primary,
    contentColor: Color = MaterialTheme.colorScheme.onPrimary,
    defaultCorner: Dp = 28.dp,
    pressedCorner: Dp = 14.dp,
    pressScale: Float = 1.065f,
    contentPadding: PaddingValues = PaddingValues(horizontal = 20.dp, vertical = 14.dp),
    border: BorderStroke? = null,
    content: @Composable RowScope.() -> Unit
) {
    val haptic = LocalHapticFeedback.current
    val interactionSource = remember { MutableInteractionSource() }
    val (scale, corner) = rememberExpressivePressState(
        interactionSource = interactionSource,
        pressScale = if (enabled) pressScale else 1f,
        defaultCorner = defaultCorner,
        pressedCorner = pressedCorner
    )

    val animatedBg by animateColorAsState(
        targetValue = if (enabled) containerColor else containerColor.copy(alpha = 0.34f),
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "btn_bg"
    )
    val animatedFg by animateColorAsState(
        targetValue = if (enabled) contentColor else contentColor.copy(alpha = 0.45f),
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "btn_fg"
    )

    Surface(
        onClick = {
            if (enabled) {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            }
        },
        enabled = enabled,
        interactionSource = interactionSource,
        shape = RoundedCornerShape(corner),
        color = animatedBg,
        contentColor = animatedFg,
        border = border,
        tonalElevation = if (enabled) 2.dp else 0.dp,
        modifier = modifier.graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
    ) {
        Row(
            modifier = Modifier.padding(contentPadding),
            horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically,
            content = content
        )
    }
}

@Composable
fun ExpressiveChip(
    selected: Boolean,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    leadingContent: (@Composable () -> Unit)? = null
) {
    val haptic = LocalHapticFeedback.current
    val interactionSource = remember { MutableInteractionSource() }
    val (scale, _) = rememberExpressivePressState(
        interactionSource = interactionSource,
        pressScale = 1.08f
    )
    val isPressed by interactionSource.collectIsPressedAsState()

    val corner by animateDpAsState(
        targetValue = when {
            isPressed -> 10.dp
            selected -> 14.dp
            else -> 24.dp
        },
        animationSpec = spring(dampingRatio = 0.55f, stiffness = 430f),
        label = "chip_corner"
    )

    val bg by animateColorAsState(
        targetValue = if (selected) MaterialTheme.colorScheme.primaryContainer
        else MaterialTheme.colorScheme.surfaceContainerHigh,
        animationSpec = spring(stiffness = Spring.StiffnessMedium),
        label = "chip_bg"
    )
    val fg by animateColorAsState(
        targetValue = if (selected) MaterialTheme.colorScheme.onPrimaryContainer
        else MaterialTheme.colorScheme.onSurfaceVariant,
        animationSpec = spring(stiffness = Spring.StiffnessMedium),
        label = "chip_fg"
    )

    Surface(
        onClick = {
            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            onClick()
        },
        interactionSource = interactionSource,
        shape = RoundedCornerShape(corner),
        color = bg,
        contentColor = fg,
        border = if (selected) BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.55f)) else null,
        modifier = modifier.graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(5.dp, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (leadingContent != null) {
                leadingContent()
            }
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun ExpressiveIconButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    containerColor: Color = MaterialTheme.colorScheme.surfaceContainerHighest,
    contentColor: Color = MaterialTheme.colorScheme.onSurface,
    defaultCorner: Dp = 24.dp,
    pressedCorner: Dp = 12.dp,
    pressScale: Float = 1.12f,
    content: @Composable () -> Unit
) {
    val haptic = LocalHapticFeedback.current
    val interactionSource = remember { MutableInteractionSource() }
    val (scale, corner) = rememberExpressivePressState(
        interactionSource = interactionSource,
        pressScale = if (enabled) pressScale else 1f,
        defaultCorner = defaultCorner,
        pressedCorner = pressedCorner
    )

    val bg by animateColorAsState(
        targetValue = if (enabled) containerColor else containerColor.copy(alpha = 0.3f),
        label = "icon_bg"
    )
    val fg by animateColorAsState(
        targetValue = if (enabled) contentColor else contentColor.copy(alpha = 0.35f),
        label = "icon_fg"
    )

    Surface(
        onClick = {
            if (enabled) {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            }
        },
        enabled = enabled,
        interactionSource = interactionSource,
        shape = RoundedCornerShape(corner),
        color = bg,
        contentColor = fg,
        modifier = modifier.graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
    ) {
        Box(
            modifier = Modifier.padding(12.dp),
            contentAlignment = Alignment.Center
        ) {
            CompositionLocalProvider(LocalContentColor provides fg) {
                content()
            }
        }
    }
}

@Composable
fun colorizePassword(password: String): AnnotatedString {
    val letterColor = MaterialTheme.colorScheme.onSurface
    val digitColor = MaterialTheme.colorScheme.secondary
    val symbolColor = MaterialTheme.colorScheme.tertiary

    return buildAnnotatedString {
        for (ch in password) {
            val style = when {
                ch.isDigit() -> SpanStyle(color = digitColor, fontWeight = FontWeight.ExtraBold)
                !ch.isLetterOrDigit() -> SpanStyle(color = symbolColor, fontWeight = FontWeight.ExtraBold)
                else -> SpanStyle(color = letterColor, fontWeight = FontWeight.Bold)
            }
            withStyle(style) {
                append(ch)
            }
        }
    }
}
