package com.lumavault.app.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Backspace
import androidx.compose.material.icons.rounded.Fingerprint
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lumavault.app.data.SecurityConfig
import com.lumavault.app.security.BiometricHelper
import com.lumavault.app.security.findFragmentActivity
import com.lumavault.app.ui.components.ExpressiveChip
import com.lumavault.app.ui.components.expressiveCookieShape
import com.lumavault.app.ui.components.rememberExpressivePressState
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

@Composable
fun LockScreen(
    isSetupMode: Boolean,
    securityConfig: SecurityConfig?,
    onSetupComplete: (pin: String, enableBiometric: Boolean) -> Unit,
    onVerifyPin: (String) -> Boolean,
    onUnlocked: () -> Unit
) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()

    val biometricAvailable = remember { BiometricHelper.isAvailable(context) }
    val biometricEnabled = securityConfig?.biometricEnabled ?: biometricAvailable

    var setupPinLength by remember { mutableIntStateOf(4) }
    val targetPinLength = if (isSetupMode) setupPinLength else (securityConfig?.pinLength ?: 4)

    var firstSetupPin by remember { mutableStateOf<String?>(null) }
    var currentPin by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var setupBiometricToggle by remember { mutableStateOf(biometricAvailable) }

    val shakeOffset = remember { Animatable(0f) }

    fun triggerError(msg: String) {
        errorMessage = msg
        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        scope.launch {
            for (delta in listOf(-24f, 24f, -18f, 18f, -10f, 10f, 0f)) {
                shakeOffset.animateTo(delta, tween(45))
            }
            delay(180)
            currentPin = ""
        }
    }

    fun launchBiometric() {
        val activity = context.findFragmentActivity() ?: return
        BiometricHelper.authenticate(
            activity = activity,
            onSuccess = onUnlocked,
            onError = { err -> errorMessage = err }
        )
    }

    LaunchedEffect(isSetupMode, biometricAvailable, biometricEnabled) {
        if (!isSetupMode && biometricAvailable && biometricEnabled) {
            delay(280)
            launchBiometric()
        }
    }

    fun onDigitPressed(digit: String) {
        if (currentPin.length >= targetPinLength) return
        errorMessage = null
        val updated = currentPin + digit
        currentPin = updated

        if (updated.length == targetPinLength) {
            if (isSetupMode) {
                if (firstSetupPin == null) {
                    scope.launch {
                        delay(150)
                        firstSetupPin = updated
                        currentPin = ""
                    }
                } else {
                    if (updated == firstSetupPin) {
                        onSetupComplete(updated, setupBiometricToggle && biometricAvailable)
                    } else {
                        firstSetupPin = null
                        triggerError("PIN-коды не совпали. Попробуйте снова")
                    }
                }
            } else {
                if (onVerifyPin(updated)) {
                    onUnlocked()
                } else {
                    triggerError("Неверный PIN-код")
                }
            }
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "cookie_spin")
    val badgeRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 28000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 24.dp, vertical = 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(top = 18.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Box(
                    modifier = Modifier
                        .size(86.dp)
                        .graphicsLayer { rotationZ = badgeRotation }
                        .clip(expressiveCookieShape(lobes = 10, depth = 0.09f))
                        .background(MaterialTheme.colorScheme.primaryContainer)
                )
                Icon(
                    imageVector = if (isSetupMode) Icons.Rounded.Shield else Icons.Rounded.Lock,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.size(34.dp)
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            AnimatedContent(
                targetState = when {
                    !isSetupMode -> "LumaVault"
                    firstSetupPin == null -> "Защитите хранилище"
                    else -> "Повторите PIN-код"
                },
                transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(150)) },
                label = "lock_title"
            ) { title ->
                Text(
                    text = title,
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                    textAlign = TextAlign.Center
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = when {
                    errorMessage != null -> errorMessage!!
                    !isSetupMode -> "Введите PIN-код или приложите палец"
                    firstSetupPin == null -> "Создайте локальный PIN. Все пароли хранятся только на этом устройстве."
                    else -> "Введите те же $targetPinLength цифр ещё раз"
                },
                style = MaterialTheme.typography.bodyMedium,
                color = if (errorMessage != null) MaterialTheme.colorScheme.error
                else MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 12.dp)
            )

            if (isSetupMode && firstSetupPin == null) {
                Spacer(modifier = Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ExpressiveChip(
                        selected = setupPinLength == 4,
                        label = "4 цифры",
                        onClick = {
                            setupPinLength = 4
                            currentPin = ""
                        }
                    )
                    ExpressiveChip(
                        selected = setupPinLength == 6,
                        label = "6 цифр",
                        onClick = {
                            setupPinLength = 6
                            currentPin = ""
                        }
                    )
                    if (biometricAvailable) {
                        ExpressiveChip(
                            selected = setupBiometricToggle,
                            label = "Отпечаток",
                            onClick = { setupBiometricToggle = !setupBiometricToggle },
                            leadingContent = {
                                Icon(
                                    imageVector = Icons.Rounded.Fingerprint,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(26.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.offset { IntOffset(shakeOffset.value.roundToInt(), 0) }
            ) {
                repeat(targetPinLength) { idx ->
                    val filled = idx < currentPin.length
                    val dotSize by animateDpAsState(
                        targetValue = if (filled) 20.dp else 14.dp,
                        animationSpec = spring(dampingRatio = 0.42f, stiffness = 500f),
                        label = "dot_size"
                    )
                    val dotCorner by animateDpAsState(
                        targetValue = if (filled) 6.dp else 10.dp,
                        animationSpec = spring(dampingRatio = 0.5f, stiffness = 450f),
                        label = "dot_corner"
                    )
                    val dotRotation by animateFloatAsState(
                        targetValue = if (filled) 45f else 0f,
                        animationSpec = spring(dampingRatio = 0.45f, stiffness = 420f),
                        label = "dot_rot"
                    )
                    val dotColor by animateColorAsState(
                        targetValue = when {
                            errorMessage != null -> MaterialTheme.colorScheme.error
                            filled -> MaterialTheme.colorScheme.primary
                            else -> MaterialTheme.colorScheme.surfaceContainerHighest
                        },
                        label = "dot_color"
                    )

                    Box(
                        modifier = Modifier.size(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(dotSize)
                                .graphicsLayer { rotationZ = dotRotation }
                                .clip(RoundedCornerShape(dotCorner))
                                .background(dotColor)
                        )
                    }
                }
            }
        }

        Column(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp)
        ) {
            val rows = listOf(
                listOf("1", "2", "3"),
                listOf("4", "5", "6"),
                listOf("7", "8", "9")
            )
            rows.forEach { row ->
                Row(
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    row.forEach { digit ->
                        ExpressivePadKey(onClick = { onDigitPressed(digit) }) {
                            Text(
                                text = digit,
                                fontSize = 26.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            Row(
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (!isSetupMode && biometricAvailable && biometricEnabled) {
                    ExpressivePadKey(
                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                        onClick = { launchBiometric() }
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Fingerprint,
                            contentDescription = "Отпечаток пальца",
                            tint = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.size(30.dp)
                        )
                    }
                } else {
                    Spacer(modifier = Modifier.size(78.dp))
                }

                ExpressivePadKey(onClick = { onDigitPressed("0") }) {
                    Text(
                        text = "0",
                        fontSize = 26.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                ExpressivePadKey(
                    containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                    onClick = {
                        if (currentPin.isNotEmpty()) {
                            currentPin = currentPin.dropLast(1)
                            errorMessage = null
                        }
                    }
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.Backspace,
                        contentDescription = "Стереть",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun ExpressivePadKey(
    onClick: () -> Unit,
    containerColor: Color = MaterialTheme.colorScheme.surfaceContainer,
    content: @Composable () -> Unit
) {
    val haptic = LocalHapticFeedback.current
    val interactionSource = remember { MutableInteractionSource() }
    val (scale, corner) = rememberExpressivePressState(
        interactionSource = interactionSource,
        pressScale = 1.12f,
        defaultCorner = 38.dp,
        pressedCorner = 18.dp
    )

    Surface(
        onClick = {
            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            onClick()
        },
        interactionSource = interactionSource,
        shape = RoundedCornerShape(corner),
        color = containerColor,
        modifier = Modifier
            .size(78.dp)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
    ) {
        Box(contentAlignment = Alignment.Center) {
            content()
        }
    }
}
