#!/usr/bin/env python3
"""Downloads authentic rounded Nunito TTF fonts (Latin + Cyrillic) into app/src/main/res/font/."""
import re
import shutil
import sys
import urllib.request
from pathlib import Path

FONT_DIR = Path("app/src/main/res/font")
FONT_DIR.mkdir(parents=True, exist_ok=True)

TARGETS = {
    "nunito_regular.ttf": ("Nunito-Regular.ttf", 400),
    "nunito_medium.ttf": ("Nunito-Medium.ttf", 500),
    "nunito_semibold.ttf": ("Nunito-SemiBold.ttf", 600),
    "nunito_bold.ttf": ("Nunito-Bold.ttf", 700),
    "nunito_extrabold.ttf": ("Nunito-ExtraBold.ttf", 800),
}

GITHUB_STATIC_BASE = "https://raw.githubusercontent.com/google/fonts/main/ofl/nunito/static/"
GITHUB_RUBIK_BASE = "https://raw.githubusercontent.com/google/fonts/main/ofl/rubik/static/"

def is_valid_font(data: bytes) -> bool:
    if len(data) < 10000:
        return False
    return data[:4] in (b"\x00\x01\x00\x00", b"OTTO", b"true", b"ttcf")

def download_bytes(url: str, headers=None) -> bytes:
    req = urllib.request.Request(url, headers=headers or {"User-Agent": "LumaVault-Builder/1.0"})
    with urllib.request.urlopen(req, timeout=30) as resp:
        return resp.read()

def fetch_from_google_css():
    css_url = "https://fonts.googleapis.com/css2?family=Nunito:wght@400;500;600;700;800"
    css = download_bytes(css_url, headers={"User-Agent": "Java/17"}).decode("utf-8", errors="ignore")
    weight_map = {}
    for block in css.split("@font-face"):
        w_match = re.search(r"font-weight:\s*(\d+)", block)
        u_match = re.search(r"url\((https://[^)]+\.ttf)\)", block)
        if w_match and u_match:
            weight_map[int(w_match.group(1))] = u_match.group(1)
    return weight_map

def main():
    css_map = None
    last_good = None
    for out_name, (gh_name, weight) in TARGETS.items():
        out_path = FONT_DIR / out_name
        if out_path.exists() and is_valid_font(out_path.read_bytes()):
            print(f"[OK] Cached {out_name}")
            last_good = out_path
            continue

        downloaded = False
        try:
            data = download_bytes(GITHUB_STATIC_BASE + gh_name)
            if is_valid_font(data):
                out_path.write_bytes(data)
                print(f"[OK] Downloaded {out_name} from Google Fonts GitHub")
                downloaded = True
        except Exception as e:
            print(f"[WARN] GitHub Nunito failed for {out_name}: {e}")

        if not downloaded:
            try:
                if css_map is None:
                    css_map = fetch_from_google_css()
                if weight in css_map:
                    data = download_bytes(css_map[weight])
                    if is_valid_font(data):
                        out_path.write_bytes(data)
                        print(f"[OK] Downloaded {out_name} from Google Fonts API")
                        downloaded = True
            except Exception as e:
                print(f"[WARN] Google Fonts API failed for {out_name}: {e}")

        if not downloaded:
            try:
                rubik_name = gh_name.replace("Nunito", "Rubik")
                data = download_bytes(GITHUB_RUBIK_BASE + rubik_name)
                if is_valid_font(data):
                    out_path.write_bytes(data)
                    print(f"[OK] Downloaded {out_name} fallback (Rubik)")
                    downloaded = True
            except Exception as e:
                print(f"[WARN] Rubik fallback failed for {out_name}: {e}")

        if not downloaded and last_good is not None:
            shutil.copyfile(last_good, out_path)
            print(f"[WARN] Reused {last_good.name} for {out_name}")
            downloaded = True

        if not downloaded:
            print(f"FATAL: Could not download rounded font {out_name}", file=sys.stderr)
            sys.exit(1)

        last_good = out_path

    print("All rounded fonts ready!")

if __name__ == "__main__":
    main()
