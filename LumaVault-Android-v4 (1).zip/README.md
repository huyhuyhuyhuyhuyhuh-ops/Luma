# LumaVault

Локальный open-source менеджер паролей для Android в стиле **Material 3 Expressive (MD3E)** с умным фонетическим и словесным генератором.
